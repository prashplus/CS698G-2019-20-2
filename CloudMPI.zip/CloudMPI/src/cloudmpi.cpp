//
// Created by prash on 2/21/2020.
//

#include <bits/stdc++.h>
#include <mpi.h>

int add(int a, int b) {
    return a+b;
}